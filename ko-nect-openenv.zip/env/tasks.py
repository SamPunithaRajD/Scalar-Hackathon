def easy_task(state):
    return max(0.0, 1 - state["delays"] * 0.2)

def medium_task(state):
    if state["demand_level"] == "high":
        return min(1.0, state["available_trains"] / 10)
    return 0.5

def hard_task(state):
    score = 1.0
    if state["delays"] > 2:
        score -= 0.3
    if state["pending_issues"] > 1:
        score -= 0.3
    if state["event"] != "none":
        score += 0.2
    return max(0.0, score)
