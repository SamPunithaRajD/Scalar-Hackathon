import random
from env.models import Observation, Action
from env.reward import calculate_reward

class KoNectEnv:
    def __init__(self):
        self.state_data = None
        self.steps = 0
        self.max_steps = 10

    def reset(self):
        self.state_data = {
            "time": 0,
            "active_drivers": 15,
            "available_trains": 8,
            "pending_issues": 1,
            "demand_level": "medium",
            "delays": 2,
            "event": "none"
        }
        self.steps = 0
        return Observation(**self.state_data)

    def trigger_event(self):
        events = ["festival", "rain", "breakdown", "none"]
        event = random.choice(events)
        self.state_data["event"] = event

        if event == "festival":
            self.state_data["demand_level"] = "high"
            self.state_data["delays"] += 2
        elif event == "rain":
            self.state_data["delays"] += 1
        elif event == "breakdown":
            self.state_data["available_trains"] -= 2
            self.state_data["delays"] += 3

    def step(self, action: Action):
        self.steps += 1
        self.state_data["time"] += 1

        self.state_data["active_drivers"] += action.assign_drivers
        self.state_data["available_trains"] += action.add_trains

        resolved = min(action.resolve_issues, self.state_data["pending_issues"])
        self.state_data["pending_issues"] -= resolved

        self.state_data["delays"] = max(
            0,
            self.state_data["delays"] - (action.assign_drivers + action.add_trains)
        )

        if self.steps % 2 == 0:
            self.trigger_event()

        reward = calculate_reward(self.state_data)
        done = self.steps >= self.max_steps

        return Observation(**self.state_data), reward, done, {}

    def state(self):
        return self.state_data
