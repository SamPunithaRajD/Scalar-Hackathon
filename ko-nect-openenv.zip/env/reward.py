def calculate_reward(state):
    score = 0.0

    score += max(0, 1 - state["delays"] * 0.1)
    score += max(0, 1 - state["pending_issues"] * 0.2)

    if state["active_drivers"] > 30:
        score -= 0.2

    if state["event"] == "festival" and state["delays"] < 2:
        score += 0.3

    return max(0.0, min(1.0, score))
