from pydantic import BaseModel

class Observation(BaseModel):
    time: int
    active_drivers: int
    available_trains: int
    pending_issues: int
    demand_level: str
    delays: int
    event: str

class Action(BaseModel):
    assign_drivers: int
    add_trains: int
    resolve_issues: int
