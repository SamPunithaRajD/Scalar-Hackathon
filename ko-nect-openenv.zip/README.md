# KO-NECT OpenEnv (Advanced)

AI-powered environment simulating urban transport operations.

## Features
- Dynamic time-based simulation
- Event-driven system (festival, rain, breakdown)
- Multi-action optimization
- Reward shaping

## Tasks
- Easy: Reduce delays
- Medium: Handle demand spikes
- Hard: Multi-factor optimization

## Run
python inference.py
